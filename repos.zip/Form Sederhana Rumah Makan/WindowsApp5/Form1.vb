﻿Public Class Form1
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbNIP.SelectedIndexChanged
        Select Case CmbNIP.Text
            Case "001"
                TxtNama.Text = "Ajo"
            Case "002"
                TxtNama.Text = "Desmon"
            Case "003"
                TxtNama.Text = "Samsul"
            Case Else
                TxtNama.Text = ""
        End Select
    End Sub

    Private Sub TxtNama_TextChanged(sender As Object, e As EventArgs) Handles TxtNama.TextChanged

    End Sub

    Private Sub CmbGol_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbGol.SelectedIndexChanged
        Select Case CmbGol.Text
            Case "IA"
                TxtGaji.Text = 1000000
            Case "IB"
                TxtGaji.Text = 2000000
            Case "IC"
                TxtGaji.Text = 3000000
            Case Else
                TxtGaji.Text = 0
        End Select
    End Sub

    Private Sub CmbJabatan_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbJabatan.SelectedIndexChanged
        Select Case CmbJabatan.Text
            Case "PembantuI"
                TxtTunj.Text = "200000"
            Case "Supervisor"
                TxtTunj.Text = "400000"
            Case "Manajer"
                TxtTunj.Text = "600000"
            Case Else
                TxtTunj.Text = 0
        End Select
    End Sub

    Private Sub CmdHapus_Click(sender As Object, e As EventArgs) Handles CmdHapus.Click
        CmbNIP.Text = ""
        TxtNama.Text = ""
        CmbGol.Text = ""
        CmbJabatan.Text = ""
        TxtGaji.Text = ""
        TxtTunj.Text = ""
        TxtTotal.Text = ""
    End Sub

    Private Sub CmdProses_Click(sender As Object, e As EventArgs) Handles CmdProses.Click
        TxtTotal.Text = Val(TxtGaji.Text) + Val(TxtTunj.Text)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CmbNIP.Items.Add("001")
        CmbNIP.Items.Add("002")
        CmbNIP.Items.Add("003")

        CmbGol.Items.Add("IA")
        CmbGol.Items.Add("IB")
        CmbGol.Items.Add("IC")

        CmbJabatan.Items.Add("PembantuI")
        CmbJabatan.Items.Add("Supervisor")
        CmbJabatan.Items.Add("Manajer")

        CmdHapus_Click(sender, e)
    End Sub
End Class
